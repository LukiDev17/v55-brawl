import json

from Classes.Commands.LogicCommand import LogicCommand
from Classes.Messaging import Messaging
from Database.DatabaseHandler import DatabaseHandler

from Classes.Files.Classes.Cards import Cards
from Classes.Files.Classes.Characters import Characters

class LogicClaimStarRoadCommand(LogicCommand):
    def __init__(self, commandData):
        super().__init__(commandData)

    def encode(self, fields):
        LogicCommand.encode(self, fields)
        self.writeDataReference(0)
        return self.messagePayload

    def decode(self, calling_instance):
        fields = {}
        LogicCommand.decode(calling_instance, fields, False)
        fields['BrawlerID'] = calling_instance.readDataReference()
        LogicCommand.parseFields(fields)
        return fields

    def execute(self, calling_instance, fields):
        db_instance = DatabaseHandler()
        player_data = json.loads(db_instance.getPlayerEntry(calling_instance.player.ID)[2])

        brawlerName = Characters.getBrawlerNameByID(fields['BrawlerID'][1])
        cardID = Cards.getCardIdByName(brawlerName)

        all_brawlers = []
        rare = [1, 2, 3, 6, 8, 10, 13, 24]
        super_rare = [7, 9, 18, 19, 22, 25, 27, 34, 61, 4]
        epic = [14, 15, 16, 20, 26, 29, 30, 36, 43, 45, 48, 50, 58, 69]
        mythic = [11, 17, 21, 35, 31, 32, 37, 42, 47, 64, 67, 71]
        legendary = [5, 12, 23, 28, 40, 52, 63]

        if fields['BrawlerID'][1] in rare:
            CreditsNeeded = 160
        if fields['BrawlerID'][1] in super_rare:
            CreditsNeeded = 430
        if fields['BrawlerID'][1] in epic:
            CreditsNeeded = 925
        if fields['BrawlerID'][1] in mythic:
            CreditsNeeded = 1900
        if fields['BrawlerID'][1] in legendary:
            CreditsNeeded = 3800

        brawler = {'CardID': cardID, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'MasteryPoints': 0, 'MasteryClaimed': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2}

        player_data['RareTokens'] = player_data['RareTokens'] - CreditsNeeded

        player_data['OwnedBrawlers'][fields['BrawlerID'][1]] = brawler

        try:
            player_data['OwnedBrawlers'][fields['BrawlerID'][1]]
            for brawlerID in rare:
                if calling_instance.player.UnlockingBrawler != brawlerID:
                    all_brawlers.append(brawlerID)
            for brawlerID in super_rare:
                if calling_instance.player.UnlockingBrawler != brawlerID:
                    all_brawlers.append(brawlerID)
            for brawlerID in epic:
                if calling_instance.player.UnlockingBrawler != brawlerID:
                    all_brawlers.append(brawlerID)
            for brawlerID in mythic:
                if calling_instance.player.UnlockingBrawler != brawlerID:
                    all_brawlers.append(brawlerID)
            for brawlerID in legendary:
                if calling_instance.player.UnlockingBrawler != brawlerID:
                    all_brawlers.append(brawlerID)
            player_data['UnlockingBrawler'] = all_brawlers[0]
        except Exception as e:
            print(e)

        db_instance.updatePlayerData(player_data, calling_instance)

        fields["Socket"] = calling_instance.client
        fields["Command"] = {"ID": 203}
        fields["PlayerID"] = calling_instance.player.ID
        Messaging.sendMessage(24111, fields)

    def getCommandType(self):
        return 562
    