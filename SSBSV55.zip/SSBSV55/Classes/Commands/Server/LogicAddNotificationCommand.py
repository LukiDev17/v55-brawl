from Classes.Commands.LogicServerCommand import LogicServerCommand


class LogicAddNotificationCommand(LogicServerCommand):
    def __init__(self, commandData):
        super().__init__(commandData)

    def encode(self, fields):
        self.writeVInt(1) # Count
        
        self.writeVInt(fields["Notification"]["Type"])
        # BaseNotification::encode
        self.writeInt(fields["Notification"]["Number"]) # Notification Index
        self.writeBoolean(False) # Read
        self.writeInt(fields["Notification"]["Timer"]) # Time Ago
        self.writeString(fields["Notification"]["Text"])
        self.writeVInt(0)
        if fields["Notification"]["Type"] == 81:
        	self.writeVInt(1)
        if fields["Notification"]["Type"] == 82:
        	self.writeString("Test")
        	self.writeVInt(0)
        	self.writeVInt(28000000)
        	self.writeVInt(43000000)
        	self.writeVInt(-1)
        if fields["Notification"]["Type"] == 72 or fields["Notification"]["Type"] == 94:
        	# VanityItemRewardNotification or SkinRewardNotification
        	DataRef = str(fields["Notification"]["DataRef"][0]) + "000000"
        	Item = int(DataRef) + fields["Notification"]["DataRef"][1]
        	self.writeVInt(Item)
        if fields["Notification"]["Type"] == 63 or fields["Notification"]["Type"] == 70:
        	# ChallengeRewardNotification
        	self.writeVInt(1)
        	for i in range(1):
        		self.writeVInt(fields["Notification"]["Reward"]["Type"])
        		self.writeVInt(fields["Notification"]["Reward"]["Amount"])
        		self.writeDataReference(fields["Notification"]["Reward"]["Brawler"][0], fields["Notification"]["Reward"]["Brawler"][1])
        		self.writeVInt(fields["Notification"]["Reward"]["Extra"])
        	self.writeVInt(fields["Notification"]["ChallengeVariation"])
        	self.writeVInt(fields["Notification"]["Win"])
        	self.writeString(fields["Notification"]["ChallengeName"])
        if fields["Notification"]["Type"] == 64:
        	# RewardNotification::encode
        	self.writeVInt(1488)
        	self.writeVInt(1488)
        	self.writeVInt(fields["Notification"]["RewardType"])
        	self.writeVInt(fields["Notification"]["Amount"])
        if fields["Notification"]["Type"] == 71:
        	# BrawlPassPointRewardNotification::encode
        	self.writeVInt(fields["Notification"]["BPSeason"])
        	self.writeVInt(fields["Notification"]["Tokens"])
        
        LogicServerCommand.encode(self, fields)
        return self.messagePayload

    def decode(self, calling_instance):
        pass

    def getCommandType(self):
        return 206