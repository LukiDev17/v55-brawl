from Classes.Commands.LogicServerCommand import LogicServerCommand
from Classes.Logic.LogicStarrDropData import starrDropOpening

class LogicRefreshRandomRewardsCommand(LogicServerCommand):
    def __init__(self, commandData):
        super().__init__(commandData)

    def encode(self, fields):
        self.writeVInt(1)
        self.writeVInt(-1)
        self.writeVInt(-1)
        self.writeVLong(0, 1)
        self.writeVInt(1)
        
        starDrop = 1
        self.writeVInt(5)
        for i in range(5):
            self.writeDataReference(80, i)
            self.writeVInt(0)
            self.writeVInt(0) # ? (а ето мб редкость ну я потом чекну)
        if starDrop != 0:
            self.writeVInt(1)
            self.writeDataReference(80, 4)
            self.writeVInt(1)

            self.writeByte(1)
            self.writeVInt(4)
            self.writeVInt(1) # Count
            self.writeDataReference(16, 0)
            self.writeVInt(52)
        else:
            self.writeVInt(0)
            self.writeVInt(0)
        self.writeInt(0)
        self.writeVInt(0) # Progress in battle
        self.writeVInt(0)
        self.writeVInt(86400*24) # Timer
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)

        return self.messagePayload

    def decode(self, calling_instance):
        fields = {}
        return LogicServerCommand.decode(calling_instance, fields)

    def getCommandType(self):
        return 228