from Classes.ByteStreamHelper import ByteStreamHelper
from Classes.Packets.PiranhaMessage import PiranhaMessage
from Classes.Logic.LogicStarrDropData import starrDropOpening
from Static.StaticData import StaticData

class OwnHomeDataMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields, player):
        ownedBrawlersCount = len(player.OwnedBrawlers)
        ownedPinsCount = len(player.OwnedPins)
        ownedThumbnailCount = len(player.OwnedThumbnails)
        ownedSkins = []

        for brawlerInfo in player.OwnedBrawlers.values():
            try:
                ownedSkins.extend(brawlerInfo["Skins"])
            except KeyError:
                continue

        self.writeVInt(0) # Date of Create Account
        self.writeVInt(0) # Date of Create Account

        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(player.Trophies + 0) # Trophies
        self.writeVInt(player.HighestTrophies + 0) # HighestTrophies
        self.writeVInt(player.HighestTrophies + 0) # HighestTrophies on day
        self.writeVInt(player.TrophyRoadTier + 1488)
        self.writeVInt(player.Experience)

        self.writeDataReference(28, player.Thumbnail) # ProfileIcon
        self.writeDataReference(43, player.Namecolor) # Namecolor

        self.writeVInt(26)
        for x in range(26):
            self.writeVInt(x)

        self.writeVInt(0)

        self.writeVInt(0)

        self.writeVInt(0)
        
        self.writeVInt(0)

        self.writeVInt(0)

        self.writeVInt(0)

        self.writeVInt(0)
        self.writeVInt(player.HighestTrophies)
        self.writeVInt(0)
        self.writeVInt(2)
        self.writeBoolean(True)
        self.writeVInt(0)
        self.writeVInt(115)
        self.writeVInt(335442)
        self.writeVInt(1001442)
        self.writeVInt(5778642) 

        self.writeVInt(120)
        self.writeVInt(200)
        self.writeVInt(0)

        self.writeBoolean(True)
        self.writeVInt(2)
        self.writeVInt(2)
        self.writeVInt(2)
        self.writeVInt(0)
        self.writeVInt(0) 
        
        ShopData = StaticData.ShopData

        self.writeVInt(len(ShopData["Offers"])) # Offers count
        
        
        
        for i in ShopData["Offers"]:
            def checkAvailability():
            	results = []
            	result = False
            	for reward in i["Rewards"]:
            		if reward["ItemType"] == 4:
            			if reward["Extra"] in ownedSkins:
            				if len(i["Rewards"]) > 1:
            					results.append(True)
            				else:
            					result = True
            			if str(reward["BrawlerID"][1]) not in list(player.OwnedBrawlers.keys()):
            				midresult = False
            				for x in i["Rewards"]:
            					if x["ItemType"] == 3:
            						midresult = True
            				if midresult != True:
            					if len(i["Rewards"]) > 1:
            						results.append(True)
            					else:
            						result = True
            		if reward["ItemType"] == 3 or reward["ItemType"] == 30:
            			if str(reward["BrawlerID"][1]) in list(player.OwnedBrawlers.keys()):
            				if len(i["Rewards"]) > 1:
            					results.append(True)
            				else:
            					result = True
            		if reward["ItemType"] == 19:
            			if reward["Extra"] in player.OwnedPins:
            				if len(i["Rewards"]) > 1:
            					results.append(True)
            				else:
            					result = True
            		if reward["ItemType"] == 25:
            			if reward["Extra"] in player.OwnedThumbnails:
            				if len(i["Rewards"]) > 1:
            					results.append(True)
            				else:
            					result = True
            	if i["Rewards"].index(reward) == len(i["Rewards"]) -1:
            		if True in results:
            			result = True
            	return result
            self.writeVInt(len(i["Rewards"]))  # RewardCount
            for reward in i["Rewards"]:
                self.writeVInt(reward["ItemType"]) # ItemType
                self.writeVInt(reward["Amount"])
                if reward["BrawlerID"][0] != 0:
                    self.writeDataReference(reward["BrawlerID"][0], reward["BrawlerID"][1]) # CsvID
                else:
                    self.writeDataReference(0)
                self.writeVInt(reward["Extra"])

            self.writeVInt(i["Currency"])
            self.writeVInt(i["Cost"])
            self.writeVInt(i["Time"])
            self.writeVInt(0) # State
            self.writeVInt(0)
            if i["OfferID"] in player.PushasedOffers or checkAvailability() == True:
            	self.writeBoolean(True) # Claim
            else:
            	self.writeBoolean(i['Claim']) # Claim
            self.writeVInt(ShopData["Offers"].index(i)) # Offer Index
            self.writeVInt(0)
            self.writeBoolean(i["DailyOffer"])
            self.writeVInt(i["OldPrice"])
            if i["Text"] == "None":
                self.writeString()
            else:
                self.writeString(i["Text"])
            if "TID" in i["Text"]:
            	self.writeVInt(1)
            elif i["Text"] == "None":
            	self.writeVInt(2)
            else:
            	self.writeVInt(0)
            self.writeBoolean(False)
            if i["Background"] == "None":
                self.writeString()
            else:
                self.writeString(i["Background"])
            self.writeVInt(-1)
            self.writeBoolean(i["Processed"])
            self.writeVInt(i["TypeBenefit"])
            self.writeVInt(i["Benefit"])
            self.writeString()
            self.writeBoolean(i["OneTimeOffer"])
            self.writeBoolean(False) # Unk
            if i["BigOffer"] == True:
            	if i["ShopPanelLayouts"] != -1:
            		self.writeDataReference(83, i["ShopPanelLayouts"]) # For Big Offers
            	else:
            		self.writeDataReference(0, 0) # For Big Offers
            	if i["ShopStyleSets"] != -1:
            		self.writeDataReference(70, i["ShopStyleSets"]) # For Big Offers
            	else:
            		self.writeDataReference(0, 0) # For Big Offers
            else:
            	self.writeDataReference(0, 0) # For Big Offers
            	self.writeDataReference(0, 0) # For Big Offers            	
            self.writeBoolean(False)
            self.writeBoolean(False)
            self.writeVInt(0)
            self.writeVInt(-1)
            self.writeVInt(0)
            self.writeBoolean(False)
            self.writeBoolean(False)
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeBoolean(False)
            self.writeVInt(0)
            self.writeBoolean(True)
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeVInt(0)
        
        self.writeVInt(20)
        self.writeVInt(1428)

        self.writeVInt(0)

        self.writeVInt(1)
        self.writeVInt(30)

        self.writeByte(1) # count brawlers selected
        self.writeDataReference(16, player.SelectedBrawlers[0]) # selected brawler
        self.writeString(player.Region) # location
        self.writeString(player.ContentCreator) # supported creator

        self.writeVInt(20)
        self.writeDataReference(2, 1)  # Unknown
        self.writeDataReference(3, player.IntValueEntry['TokensGained'])  # Tokens Gained
        self.writeDataReference(4, player.IntValueEntry['TrophiesGained'])  # Trophies Gained
        self.writeDataReference(6, player.IntValueEntry['DemoAccount'])  # Demo Account
        self.writeDataReference(7, player.IntValueEntry['InvitesBlock'])  # Invites Blocked
        self.writeDataReference(8, player.IntValueEntry['StarPointsGained'])  # Star Points Gained
        self.writeDataReference(9, 1)  # Show Star Points
        self.writeDataReference(10, 0)  # Power Play Trophies Gained
        self.writeDataReference(12, 1)  # Unknown
        self.writeDataReference(14, 0)  # Coins Gained
        self.writeDataReference(15, player.IntValueEntry['SocialAge'])  # AgeScreen | 3 = underage (disable social media) | 1 = age popup
        self.writeDataReference(16, 1)
        self.writeDataReference(17, 0)  # Team Chat Muted
        self.writeDataReference(18, 1)  # Esport Button
        self.writeDataReference(19, 0)  # Champion Ship Lives Buy Popup
        self.writeDataReference(20, player.IntValueEntry['GemsGained'])  # Gems Gained
        self.writeDataReference(21, 0)  # Looking For Team State
        self.writeDataReference(22, 1)
        self.writeDataReference(23, 0)  # Club Trophies Gained
        self.writeDataReference(24, 1)  # Have already watched club league stupid animation

        self.writeVInt(0)

        Free32LVL = 75
        Free64LVL = 75
        Free96LVL = 75

        Pass32LVL = 75
        Pass64LVL = 75
        Pass96LVL = 75

        for LVL in player.BrawlPassFreeLevel:
            if LVL < 30:
                Free32LVL += (2**(LVL + 2))
            if LVL > 30:
                Free64LVL += (2**(LVL-30))
            if LVL > 61:
                Free96LVL += (1**(LVL-61))
        
        for LVL in player.BrawlPassLevel:
            if LVL < 30:
                Pass32LVL += (2**(LVL + 2))
            if LVL > 29:
                Pass64LVL += (2**(LVL-30))
            if LVL > 60:
                Pass96LVL += (1**(LVL-61))

        # BrawlPassSeasonData::encode
        self.writeVInt(1)
        for season in range(1):
            self.writeVInt(26)
            self.writeVInt(player.BPTokens + 99)
            self.writeBoolean(True) # BrawlPass buy
            self.writeVInt(0)
            self.writeBoolean(False)

            self.writeBoolean(True)
            self.writeInt(Pass32LVL)
            self.writeInt(Pass64LVL)
            self.writeInt(Pass96LVL)
            self.writeInt(0)

            self.writeBoolean(True)
            self.writeInt(Free32LVL)
            self.writeInt(Free64LVL)
            self.writeInt(Free96LVL)
            self.writeInt(0)

            self.writeBoolean(False) # BrawlPass + Buy
            self.writeBoolean(True)
            self.writeInt(0)
            self.writeInt(0)
            self.writeInt(0)
            self.writeInt(0)
        # BrawlPassSeasonData::encode

        self.writeVInt(0)

        self.writeBoolean(True)
        self.writeVInt(0)
        self.writeVInt(1)
        self.writeVInt(2)
        self.writeVInt(0) 

        self.writeBoolean(True) # Vanity items
        self.writeVInt(len(player.OwnedThumbnails)+len(player.OwnedPins))
        for ThumbnailID in player.OwnedThumbnails:
            self.writeDataReference(28, ThumbnailID)
            self.writeVInt(0)
        for EmoteID in player.OwnedPins:
            self.writeDataReference(52, EmoteID)
            self.writeVInt(0)

        self.writeBoolean(True) # Power league season data
        # Power League Data Array Start #
        self.writeVInt(1) # Season
        self.writeVInt(0) # Rank Solo League (Tokens)
        self.writeVInt(1) # Season
        self.writeVInt(0) # Rank Team League (Tokens)
        self.writeVInt(0) # Unk
        self.writeVInt(0) # High Rank Solo League (Tokens)
        self.writeVInt(0) # Unk
        self.writeVInt(0) # High Rank Team League (Tokens)
        self.writeVInt(0) # Unk
        self.writeBoolean(True) # ?
        self.writeVInt(0) # ?
        self.writeVInt(0) # ?
        # Power League Data Array End #

        self.writeInt(0)
        self.writeVInt(0)
        self.writeDataReference(16, 0) # FavoriteBrawler
        self.writeBoolean(False) # я вообще не ебу что ето на там LogicGemOffer::encode
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0) # new v54

        self.writeVInt(2023189)

        self.writeVInt(35) # event slot id
        self.writeVInt(1)
        self.writeVInt(2)
        self.writeVInt(3)
        self.writeVInt(4)
        self.writeVInt(5)
        self.writeVInt(6)
        self.writeVInt(7)
        self.writeVInt(8)
        self.writeVInt(9)
        self.writeVInt(10)
        self.writeVInt(11)
        self.writeVInt(12)
        self.writeVInt(13) 
        self.writeVInt(14)
        self.writeVInt(15)
        self.writeVInt(16)
        self.writeVInt(17)
        self.writeVInt(18) 
        self.writeVInt(19)
        self.writeVInt(20)
        self.writeVInt(21) 
        self.writeVInt(22)
        self.writeVInt(23)
        self.writeVInt(24)
        self.writeVInt(25)
        self.writeVInt(26)
        self.writeVInt(27)
        self.writeVInt(28)
        self.writeVInt(29)
        self.writeVInt(30)
        self.writeVInt(31)
        self.writeVInt(32)
        self.writeVInt(33)
        self.writeVInt(34)
        self.writeVInt(35)

        self.writeVInt(1)

        self.writeVInt(2)
        self.writeVInt(2)
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(72292)
        self.writeVInt(10) 
        self.writeDataReference(15, 730) # map id
        self.writeVInt(-1)
        self.writeVInt(2)
        self.writeString("")
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False) # MapMaker map structure array
        self.writeVInt(0)
        self.writeBoolean(False) # Power League array entry
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(-1)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(-1)
        self.writeVInt(0) 
        self.writeVInt(0) 
        self.writeVInt(0) 
        self.writeBoolean(False) 
        self.writeBoolean(False)

        self.writeVInt(0)

        ByteStreamHelper.encodeIntList(self, [20, 35, 75, 140, 290, 480, 800, 1250, 1875, 2800])
        ByteStreamHelper.encodeIntList(self, [30, 80, 170, 360]) # Shop Coins Price
        ByteStreamHelper.encodeIntList(self, [300, 880, 2040, 4680]) # Shop Coins Amount

        self.writeVInt(1) # Locked Brawler
        for i in range(1):
            self.writeDataReference(16, 80)
            self.writeInt(3600) # Time
            self.writeInt(3500)
            self.writeInt(3400)
            self.writeBoolean(True)

        self.writeVInt(7) # IntValueEntry::encode
        self.writeDataReference(41000099, 1) # ThemeID
        self.writeDataReference(112, 1) # mastery
        self.writeDataReference(110, 1) # хз вроде старрдропы х2
        self.writeDataReference(14, 0)  # Double Token Event
        self.writeDataReference(31, 0)  # Gold rush event
        self.writeDataReference(29, 27)
        self.writeDataReference(29, 12) # Skin Group Active For Campaign
        

        self.writeVInt(0) 
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)

        self.writeVInt(2)
        self.writeVInt(1)
        self.writeVInt(2)
        self.writeVInt(2)
        self.writeVInt(1)
        self.writeVInt(-1)
        self.writeVInt(2)
        self.writeVInt(1)
        self.writeVInt(4)

        ByteStreamHelper.encodeIntList(self, [0, 29, 79, 169, 349, 699])
        ByteStreamHelper.encodeIntList(self, [0, 160, 450, 500, 1250, 2500])

        self.writeLong(player.ID[0], player.ID[1]) # Player ID
        
        self.writeVInt(1)  # Уведы start
 
        try:
        	player.Notifications
        except KeyError:
        	player.Notifications = []
        notifications = player.Notifications
        notifications.sort(key = lambda x: x["Number"], reverse = True)
        self.writeVInt(len(notifications)) # Notification Count
        for x in notifications:
        	# BaseNotification::encode
        	self.writeVInt(x["Type"])
        	self.writeInt(notifications.index(x)) # Notification Index
        	self.writeBoolean(x["Readed"]) # Read
        	self.writeInt(x["Timer"]) # Time Ago
        	self.writeString(x["Text"])
        	if x["Type"] == 64:
        		# BoxRewardNotification::encode
        		self.writeVInt(1488)
        		self.writeVInt(1488)
        		self.writeVInt(x["Reward"]["Type"])
        		self.writeVInt(x["Amount"])
        
        self.writeVInt(1)
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeVInt(0) 
        self.writeVInt(0)
        self.writeBoolean(False) # Login Calendar
        self.writeVInt(0)

        self.writeBoolean(True) # Starr Road
        
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        
        self.writeVInt(1) # Unlocking Brawler

        all_brawlers = []
        rare = [1, 2, 3, 6, 8, 10, 13, 24]
        super_rare = [7, 9, 18, 19, 22, 25, 27, 34, 61, 4]
        epic = [14, 15, 16, 20, 26, 29, 30, 36, 43, 45, 48, 50, 58, 69]
        mythic = [11, 17, 21, 35, 31, 32, 37, 42, 47, 64, 67, 71]
        legendary = [5, 12, 23, 28, 40, 52, 63]
        for brawlerID in rare:
            if player.UnlockingBrawler != brawlerID:
                all_brawlers.append(brawlerID)
        for brawlerID in super_rare:
            if player.UnlockingBrawler != brawlerID:
                all_brawlers.append(brawlerID)

        x = player.UnlockingBrawler

        if x in rare:
            CreditsNeeded = 160
            GemsNeeded = 29
        if x in super_rare:
            CreditsNeeded = 430
            GemsNeeded = 79
        if x in epic:
            CreditsNeeded = 925
            GemsNeeded = 169
        if x in mythic:
            CreditsNeeded = 1900
            GemsNeeded = 349
        if x in legendary:
            CreditsNeeded = 3800
            GemsNeeded = 699
        
        self.writeDataReference(16, player.UnlockingBrawler)
        self.writeVInt(CreditsNeeded) # CreditsNeeded
        self.writeVInt(GemsNeeded) # GemsNeeded
        self.writeVInt(0)
        self.writeVInt(player.RareTokens) # CollectedCredits
        self.writeVInt(0)
        self.writeVInt(0)
 
        brawlerIndex = 0
        rareIndex = 0
        superRareIndex = 0
        epicIndex = 0
        mythicIndex = 0
        legendaryIndex = 0

        self.writeVInt(0)

        self.writeVInt(0)
        self.writeVInt(0)
        # StarRoad::encode End

        self.writeVInt(0) # Mastery

        #BattleCard
        self.writeDataReference(28, player.battleIcon) # Icon 1
        self.writeDataReference(28, player.battleIcon1) # Icon 2
        self.writeDataReference(52, player.battlePin) # Pin
        self.writeDataReference(76, player.battleTitle) # Title
        self.writeVInt(0)
        self.writeBoolean(False)  # v48
        self.writeBoolean(False)  # v48
        self.writeBoolean(False)  # v48
        self.writeBoolean(False)  # v48

        self.writeVInt(0) # Brawler's BattleCards

        # StarDrops
        self.writeVInt(5)
        for i in range(5):
            self.writeDataReference(80, i)
            self.writeVInt(1) # LogicGemOffer::encode (оно типо спавнит предмет)
            self.writeVInt(1) # ? (а ето мб редкость ну я потом чекну)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeInt(-1788180018)
        self.writeVInt(0) 
        self.writeVInt(0)
        self.writeVInt(86400*24)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(4)
        # StarDrops

        self.writeBoolean(False)

        self.writeBoolean(False)

        # end LogicClientHome
        
        self.writeInt(0) # new v54 (по либе тут не инт но оно работает и так)

        self.writeVLong(player.ID[0], player.ID[1])
        self.writeVLong(player.ID[0], player.ID[1])
        self.writeVLong(player.ID[0], player.ID[1])
        self.writeStringReference(player.Name)
        self.writeBoolean(player.Registered)
        self.writeInt(-1)

        self.writeVInt(17)
        unlocked_brawler = [i['CardID'] for x,i in player.OwnedBrawlers.items()]
        self.writeVInt(len(unlocked_brawler) + 2)
        for x in unlocked_brawler:
            self.writeDataReference(23, x)
            self.writeVInt(-1)
            self.writeVInt(1)

        self.writeDataReference(5, 8)
        self.writeVInt(-1)
        self.writeVInt(player.Coins)

        self.writeDataReference(5, 23)
        self.writeVInt(-1)
        self.writeVInt(player.Blings)

        self.writeVInt(len(player.OwnedBrawlers)) # HeroScore
        for x,i in player.OwnedBrawlers.items():
            self.writeDataReference(16, x)
            self.writeVInt(-1)
            self.writeVInt(i["Trophies"])

        self.writeVInt(len(player.OwnedBrawlers)) # HeroHighScore
        for x,i in player.OwnedBrawlers.items():
            self.writeDataReference(16, x)
            self.writeVInt(-1)
            self.writeVInt(i["HighestTrophies"])

        self.writeVInt(0) # Array

        self.writeVInt(0) # HeroPower
        
        self.writeVInt(len(player.OwnedBrawlers)) # HeroLevel
        for x,i in player.OwnedBrawlers.items():
            self.writeDataReference(16, x)
            self.writeVInt(-1)
            self.writeVInt(i["PowerLevel"]-1)

        self.writeVInt(0) # hero star power gadget and hypercharge

        self.writeVInt(len(player.OwnedBrawlers)) # HeroSeenState
        for x,i in player.OwnedBrawlers.items():
            self.writeDataReference(16, x)
            self.writeVInt(-1)
            self.writeVInt(2)

        self.writeVInt(0) # Array
        self.writeVInt(0) # Array
        self.writeVInt(0) # Array
        self.writeVInt(0) # Array
        self.writeVInt(0) # Array
        self.writeVInt(0) # Array
        self.writeVInt(0) # Array
        self.writeVInt(0) # Array
        self.writeVInt(0) # Array

        self.writeVInt(player.Gems) # Diamonds
        self.writeVInt(player.Gems) # Free Diamonds
        self.writeVInt(10) # Player Level
        self.writeVInt(100)
        self.writeVInt(0) # CumulativePurchasedDiamonds or Avatar User Level Tier | 10000 < Level Tier = 3 | 1000 < Level Tier = 2 | 0 < Level Tier = 1
        self.writeVInt(100) # Battle Count
        self.writeVInt(10) # WinCount
        self.writeVInt(80) # LoseCount
        self.writeVInt(50) # WinLooseStreak
        self.writeVInt(20) # NpcWinCount
        self.writeVInt(0) # NpcLoseCount
        self.writeVInt(2) # TutorialState | shouldGoToFirstTutorialBattle = State == 0
        self.writeVInt(12)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeString()
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(1)

    def decode(self):
        fields = {}
        return fields

    def execute(message, calling_instance, fields):
        pass

    def getMessageType(self):
        return 24101

    def getMessageVersion(self):
        return self.messageVersion