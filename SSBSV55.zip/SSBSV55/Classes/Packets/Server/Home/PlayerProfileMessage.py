from Classes.ClientsManager import ClientsManager
from Classes.Packets.PiranhaMessage import PiranhaMessage
from Classes.Wrappers.PlayerProfile import PlayerProfile
from Database.DatabaseHandler import DatabaseHandler

class PlayerProfileMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields):
        db_instance = DatabaseHandler()
        #playerData = db_instance.getPlayer(fields["PlayerID"])

        self.writeVLong(0, 1)
        self.writeDataReference(16,11) # 

        self.writeVInt(0)
        
        self.writeVInt(0)

        self.writeString('sprkdv')  #PlayerInfo
        self.writeVInt(100)
        self.writeVInt(28000000 + 0)
        self.writeVInt(43000000 + 0)
        self.writeVInt(14)

        self.writeBoolean(False)

        self.writeString("hello world")
        self.writeVInt(100)
        self.writeVInt(200)
        self.writeDataReference(29, 558)
        self.writeDataReference(0)
        self.writeDataReference(0)
        self.writeDataReference(0)
        self.writeDataReference(0)

        self.writeBoolean(False) #alliance

        self.writeDataReference(25, 1) #alliance role
        self.writeVInt(16)

    def decode(self):
        return {}

    def execute(message, calling_instance, fields):
        pass

    def getMessageType(self):
        return 24113

    def getMessageVersion(self):
        return self.messageVersion