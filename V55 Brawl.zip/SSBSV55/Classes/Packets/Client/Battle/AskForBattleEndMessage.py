from Classes.Messaging import Messaging

from Classes.Packets.PiranhaMessage import PiranhaMessage
from Database.DatabaseHandler import DatabaseHandler
import json
import Configuration
from Configuration import settings

OwnedBrawlersLatest = {
    0: {'CardID': 0, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    1: {'CardID': 4, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    2: {'CardID': 8, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    3: {'CardID': 12, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    4: {'CardID': 16, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    5: {'CardID': 20, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    6: {'CardID': 24, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    7: {'CardID': 28, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    8: {'CardID': 32, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    9: {'CardID': 36, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    10: {'CardID': 40, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    11: {'CardID': 44, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    12: {'CardID': 48, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    13: {'CardID': 52, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    14: {'CardID': 56, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    15: {'CardID': 60, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    16: {'CardID': 64, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    17: {'CardID': 68, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    18: {'CardID': 72, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    19: {'CardID': 95, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    20: {'CardID': 100, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    21: {'CardID': 105, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    22: {'CardID': 110, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    23: {'CardID': 115, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    24: {'CardID': 120, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    25: {'CardID': 125, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    26: {'CardID': 130, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    27: {'CardID': 177, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    28: {'CardID': 182, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    29: {'CardID': 188, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    30: {'CardID': 194, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    31: {'CardID': 200, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    32: {'CardID': 206, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    34: {'CardID': 218, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    35: {'CardID': 224, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    36: {'CardID': 230, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    37: {'CardID': 236, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    38: {'CardID': 279, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    39: {'CardID': 296, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    40: {'CardID': 303, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    41: {'CardID': 320, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    42: {'CardID': 327, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    43: {'CardID': 334, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    44: {'CardID': 341, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    45: {'CardID': 358, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    46: {'CardID': 365, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    47: {'CardID': 372, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    48: {'CardID': 379, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    49: {'CardID': 386, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    50: {'CardID': 393, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    51: {'CardID': 410, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    52: {'CardID': 417, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    53: {'CardID': 427, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    54: {'CardID': 434, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    56: {'CardID': 448, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    57: {'CardID': 466, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    58: {'CardID': 474, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    59: {'CardID': 491, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    60: {'CardID': 499, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
        61: {'CardID': 507, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
        62: {'CardID': 515, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
        63: {'CardID': 523, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
        64: {'CardID': 531, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
        65: {'CardID': 539, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
        66: {'CardID': 547, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
        67: {'CardID': 557, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
        68: {'CardID': 565, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
        69: {'CardID': 573, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
        70: {'CardID': 581, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
        71: {'CardID': 589, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
        72: {'CardID': 597, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
        73: {'CardID': 605, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
        74: {'CardID': 619, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
        75: {'CardID': 633, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
        76: {'CardID': 642, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
        77: {'CardID': 655, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
        78: {'CardID': 663, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
        79: {'CardID': 671, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0}
}


class AskForBattleEndMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields):
        pass

    def decode(self):
        fields = {}
        fields["Unk"] = self.readVInt()
        fields["Result"] = self.readVInt()
        fields["Rank"] = self.readVInt()
        fields["MapID"] = self.readDataReference()
        fields["HeroesCount"] = self.readVInt()
        fields["Heroes"] = []
        for i in range(fields["HeroesCount"]): fields["Heroes"].append({"Brawler": {"ID": self.readDataReference(), "SkinID": self.readDataReference()}, "Team": self.readVInt(), "IsPlayer": self.readBoolean(), "PlayerName": self.readString()})
        super().decode(fields)
        return fields

    def execute(message, calling_instance, fields):
        db_instance = DatabaseHandler()
        player_data = json.loads(db_instance.getPlayerEntry(calling_instance.player.ID)[2])
        PlayersTeams = []
        for heroEntry in fields["Heroes"]:
        	PlayersTeams.append(heroEntry["Team"])
        PlayerTeam = PlayersTeams[0]
        PlayerTeamMembers = 0
        for v in PlayersTeams:
        	if v == PlayerTeam:
        		PlayerTeamMembers += 1
        fields["PlayerThumbnail"] = player_data["Thumbnail"]
        fields["PlayerNamecolor"] = player_data["Namecolor"]
        try:
        	player_data["BPActivated"]
        except KeyError:
        	player_data["BPActivated"] = False
        fields["PlayerBPActivated"] = player_data["BPActivated"]
        if fields["MapID"][1] in Configuration.settings["ChallengeMaps"]:
        	fields["ChallengeVariation"] = Configuration.settings["ChallengeVariation"]
        else:
        	fields["ChallengeVariation"] = -1
        if fields["HeroesCount"] == 10 and PlayerTeamMembers == 2:
        	fields["GameMode"] = 5
        	if fields["Rank"] >= 3:
        		fields["Result"] = 1
        elif fields["HeroesCount"] == 10:
        	fields["GameMode"] = 2
        	if fields["Rank"] >= 5:
        		fields["Result"] = 1
        elif fields["HeroesCount"] == 3 and fields["MapID"][1] in [27, 29, 39, 68]:
        	fields["GameMode"] = 3
        elif fields["HeroesCount"] == 3 and fields["MapID"][1] in [57, 67, 133]:
        	fields["GameMode"] = 6
        elif fields["HeroesCount"] == 6 and fields["MapID"][1] in [21, 30, 65, 66, 119, 120]:
        	fields["GameMode"] = 4
        	if PlayerTeam == 1:
        		if fields["Result"] == 0:
        			fields["Result"] = 1
        		elif fields["Result"] == 1:
        			fields["Result"] = 0
        		for heroEntry in fields["Heroes"]:
        			if heroEntry["Team"] == 0:
        				heroEntry["Team"] = 1
        			elif heroEntry["Team"] == 1:
        				heroEntry["Team"] = 0
        else:
        	fields["GameMode"] = 1
        	if PlayerTeam == 1:
        		if fields["Result"] == 0:
        			fields["Result"] = 1
        		elif fields["Result"] == 1:
        			fields["Result"] = 0
        		for heroEntry in fields["Heroes"]:
        			if heroEntry["Team"] == 0:
        				heroEntry["Team"] = 1
        			elif heroEntry["Team"] == 1:
        				heroEntry["Team"] = 0
        for heroEntry in fields["Heroes"]:
        	if heroEntry["IsPlayer"]:
        		for i,v in player_data["OwnedBrawlers"].items():
        		  			if v["CardID"] == OwnedBrawlersLatest[heroEntry["Brawler"]["ID"][1]]["CardID"]:
        		  				fields["Trophies"] = v["Trophies"]
        		  				fields["HighestTrophies"] = v["HighestTrophies"]
        		  				if fields["ChallengeVariation"] == -1:
        		  					if fields["Result"] == 0:
        		  						if v["Trophies"] <= 500:
        		  						    v["Trophies"] += settings["WinTrophies"]
        		  						    v["Mastery"] += settings["WinMastery"]
        		  						if v["Trophies"] >= 500:
        		  						    v["Trophies"] += settings["WinTrophies"]
        		  						    v["Mastery"] += settings["WinMastery"]
        		  						if v["Trophies"] >= 1000:
        		  						    v["Trophies"] += settings["WinTrophies"]
        		  						    v["Mastery"] += settings["WinMastery"]
        		  						if v["Trophies"] >= 1250:
        		  						    v["Trophies"] += settings["WinTrophies"]
        		  						    v["Mastery"] += settings["WinMastery"]
        		  					if fields["Result"] == 1:
        		  						if v["Trophies"] <= 500:
        		  						    v["Trophies"] += settings["WinTrophies"]
        		  						    v["Mastery"] += settings["WinMastery"]
        		  						if v["Trophies"] >= 500:
        		  						    v["Trophies"] += settings["WinTrophies"]
        		  						    v["Mastery"] += settings["WinMastery"]
        		  						if v["Trophies"] >= 1000:
        		  						    v["Trophies"] += settings["WinTrophies"]
        		  						    v["Mastery"] += settings["WinMastery"]
        		  						if v["Trophies"] >= 1250:
        		  						    v["Trophies"] += settings["WinTrophies"]
        		  						    v["Mastery"] += settings["WinMastery"]
        		  					if v["Trophies"] > v["HighestTrophies"]:
        		  						v["HighestTrophies"] = v["Trophies"]
        fields["TokensGained"] = 0
        fields["TrophiesResult"] = 0
        fields["DoubleTokenEvent"] = 0
        fields["CoinShowEvent"] = 0
        fields["RewardTokens"] = 0
        fields["RewardCoins"] = 0
        fields["RewardGems"] = 0
        fields["RewardStarPoints"] = 0
        for heroEntry in fields["Heroes"]:
        	if heroEntry["IsPlayer"]:
        		for i,v in player_data["OwnedBrawlers"].items():
        		  			if v["CardID"] == OwnedBrawlersLatest[heroEntry["Brawler"]["ID"][1]]["CardID"]:
        		  				if v["Trophies"] <= 500:
        		  				    player_data["StarPoints"] += 20
        		  				    fields["TokensGained"] = 500
        		  				    fields["TrophiesResult"] = settings["WinTrophies"]
        		  				    player_data["BPTokens"] += 500
        		  				    player_data["Trophies"] += settings["WinTrophies"]   		  				    
        		  				    player_data["HighestTrophies"] += settings["WinTrophies"]
        		  				if v["Trophies"] >= 500:
        		  				    player_data["StarPoints"] += 40
        		  				    fields["TokensGained"] = 500
        		  				    fields["TrophiesResult"] = settings["WinTrophies"]
        		  				    player_data["BPTokens"] += 500
        		  				    player_data["Trophies"] += settings["WinTrophies"]
        		  				    player_data["HighestTrophies"] += settings["WinTrophies"]
        		  				if v["Trophies"] >= 1000:
        		  				    player_data["StarPoints"] += 80
        		  				    fields["TokensGained"] = 500
        		  				    fields["TrophiesResult"] = settings["WinTrophies"]
        		  				    player_data["BPTokens"] += 500
        		  				    player_data["Trophies"] += settings["WinTrophies"]
        		  				    player_data["HighestTrophies"] += settings["WinTrophies"]
        		  				if v["Trophies"] >= 1250:
        		  				    player_data["StarPoints"] += 160
        		  				    fields["TokensGained"] = 500
        		  				    fields["TrophiesResult"] = settings["WinTrophies"]
        		  				    player_data["BPTokens"] += 500
        		  				    player_data["Trophies"] += settings["WinTrophies"]
        		  				    player_data["HighestTrophies"] += settings["WinTrophies"]
        
        try:
        	player_data["Logs"]
        except KeyError:
        	player_data["Logs"] = []
        fields["ChallengeReward"] = {}
        fields["ChallengeWin"] = 0
        fields["ChallengeLosses"] = 0
        if fields["ChallengeVariation"] == -1:
        	if fields["Result"] == 0:
        		log = {'Trophies': 8, 'Result': 0, 'MapID': fields["MapID"], 'ChallengeVariation': fields["ChallengeVariation"], 'Number': len(player_data["Logs"])}
        	if fields["Result"] == 1:
        		log = {'Trophies': -5, 'Result': 1, 'MapID': fields["MapID"], 'ChallengeVariation': fields["ChallengeVariation"], 'Number': len(player_data["Logs"]) + 1}
        	if fields["Result"] == 2:
        		log = {'Trophies': 0, 'Result': 2, 'MapID': fields["MapID"], 'ChallengeVariation': fields["ChallengeVariation"], 'Number': len(player_data["Logs"]) + 1}
        else:
        	if fields["Result"] == 0:
        		log = {'Trophies': 0, 'Result': 0, 'MapID': fields["MapID"], 'ChallengeVariation': fields["ChallengeVariation"], 'Number': len(player_data["Logs"]) + 1}
        		try:
        		    player_data["Notifications"]
        		except KeyError:
        			player_data["Notifications"] = []
        		challenge = Configuration.settings["ChallengeLogicName"]
        		for x in Configuration.settings["ChallengeRewards"]:
        			if x["Win"] == player_data["Challenges"][challenge]["Wins"]:
        				if x["Type"] == 1 or x["Type"] == 16 or x["Type"] == 17 or x["Type"] == 28:
        					if x["Type"] == 1:
        						player_data["Coins"] += x["Amount"]
        						fields["RewardCoins"] += x["Amount"]
        					elif x["Type"] == 17:
        						player_data["StarPoints"] += x["Amount"]
        						try:
        							player_data["StarPointsGained"]
        						except KeyError:
        							player_data["StarPointsGained"] = 0 
        						fields["RewardStarPoints"] += x["Amount"]
        					elif x["Type"] == 16:
        						player_data["Gems"] += x["Amount"]
        						try:
        							player_data["GemsGained"]
        						except KeyError:
        							player_data["GemsGained"] = 0 
        						fields["RewardGems"] += x["Amount"]
        					elif x["Type"] == 28:
        						player_data["BPTokens"] += x["Amount"]
        						fields["RewardTokens"] += x["Amount"]
        				if x["Type"] == 19 or x["Type"] == 25 or x["Type"] == 4 or x["Type"] == 6 or x["Type"] == 14 or x["Type"] == 10:
        					notification = {"Type": 63, "Readed": False, "Timer": 999, "Text": "", "Reward": {"Type": x["Type"], "Amount": x["Amount"], "Brawler": x["Brawler"], "Extra": x["Extra"]}, "ChallengeVariation": fields["ChallengeVariation"], "Win": player_data["Challenges"][challenge]["Wins"], "ChallengeName": Configuration.settings["ChallengeName"], "Number": len(player_data["Notifications"]) + 1}
        					player_data["Notifications"].append(notification)
        				fields["ChallengeWin"] = player_data["Challenges"][challenge]["Wins"]
        				fields["ChallengeReward"] = {"Type": x["Type"], "Amount": x["Amount"], "Brawler": x["Brawler"], "Extra": x["Extra"]}
        		if player_data["Challenges"][challenge]["Wins"] == Configuration.settings["ChallengeTotalWins"]:
        			reward = Configuration.settings["ChallengeFinalReward"]
        			if reward["Type"] == 19 or reward["Type"] == 25 or reward["Type"] == 4 or reward["Type"] == 6 or reward["Type"] == 14 or reward["Type"] == 10:
        				notification = {"Type": 63, "Readed": False, "Timer": 999, "Text": "", "Reward": {"Type": reward["Type"], "Amount": reward["Amount"], "Brawler": reward["Brawler"], "Extra": reward["Extra"]}, "ChallengeVariation": fields["ChallengeVariation"], "Win": player_data["Challenges"][challenge]["Wins"], "ChallengeName": Configuration.settings["ChallengeName"], "Number": len(player_data["Notifications"]) + 1}
        				player_data["Notifications"].append(notification)
        	if fields["Result"] == 1:
        		log = {'Trophies': 0, 'Result': 1, 'MapID': fields["MapID"], 'ChallengeVariation': fields["ChallengeVariation"], 'Number': len(player_data["Logs"]) + 1}
        		challenge = Configuration.settings["ChallengeLogicName"]
        		fields["ChallengeLosses"] = player_data["Challenges"][challenge]["Defeates"]
        	if fields["Result"] == 2:
        		log = {'Trophies': 0, 'Result': 2, 'MapID': fields["MapID"], 'ChallengeVariation': fields["ChallengeVariation"], 'Number': len(player_data["Logs"]) + 1}
        player_data['Logs'].append(log)
        db_instance.updatePlayerData(player_data, calling_instance)
        fields["Socket"] = calling_instance.client
        Messaging.sendMessage(23456, fields, calling_instance.player)

    def getMessageType(self):
        return 14110

    def getMessageVersion(self):
        return self.messageVersion
