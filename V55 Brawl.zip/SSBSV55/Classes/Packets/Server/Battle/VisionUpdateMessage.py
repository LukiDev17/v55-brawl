from Classes.Packets.PiranhaMessage import PiranhaMessage
import random
from Classes.BitStream import BitStream

class VisionUpdateMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields, player):
        player.battleTick += 1
        self.writeVInt(fields["BattleTick"] + player.battleTick) # Battle Tick
        self.writeVInt(0) # wifi posral jidko
        self.writeVInt(0) # Commands Count
        self.writeVInt(fields["BattleTick"]) # spectators
        self.writeBoolean(True) # Live Boolean
        
        #self.writeBoolean(False)
        
        stream = BitStream()
        b = BitStream()
        
        stream.writePositiveInt(1000000 + 0, 21)
        stream.writePositiveVInt(0, 4)
        stream.writePositiveInt(20, 1)
        stream.writeBoolean(False)
        stream.writeBoolean(False)
        stream.writeBoolean(False)
        stream.writeBoolean(False)
        stream.writeInt(-1, 4) #Win/Lose
        
        stream.writeBoolean(False)
        stream.writeBoolean(False)
        stream.writeBoolean(False)
        stream.writeBoolean(False)
        
        stream.writeBoolean(False)
        stream.writeBoolean(False)
        stream.writeBoolean(False)
        stream.writeBoolean(False)
        stream.writeBoolean(False) 
        stream.writeBoolean(False)
        stream.writeBoolean(False)
        stream.writeBoolean(False)
        stream.writeBoolean(False)
        stream.writeBoolean(False) 
        stream.writeBoolean(False) 
        stream.writeBoolean(False)
        stream.writeBoolean(False)
        stream.writeBoolean(False)
        stream.writeBoolean(False)
        stream.writeBoolean(False) 
        stream.writeBoolean(False)
        stream.writeBoolean(False)
        stream.writeBoolean(False)
        stream.writeBoolean(False)
        stream.writeBoolean(False) 
        stream.writeBoolean(False)  
        stream.writeBoolean(False)
        stream.writeBoolean(True) 
        stream.writeBoolean(False)
        stream.writeBoolean(False) #HasUlti
        
        #stream.writeBoolean(False) #idk
    #	stream.writeBoolean(False) #idk
    #	stream.writeBoolean(False) #idk
        
        stream.writeBoolean(False)
        
        stream.writeBoolean(False) #idk
        stream.writeBoolean(False)
        stream.writeBoolean(False)
        stream.writeBoolean(False) #gadget use effect
        stream.writeBoolean(False)
        stream.writeBoolean(False)
        stream.writeBoolean(False)
        stream.writeBoolean(False) #idk
        stream.writeBoolean(False)
        stream.writeBoolean(False)
        stream.writeBoolean(False) #gadget use effect
        stream.writeBoolean(False)

        stream.writeBoolean(False) #idk
        stream.writeBoolean(False)
        stream.writeBoolean(False)
        stream.writeBoolean(False) #gadget use effect
        stream.writeBoolean(False)
        stream.writeBoolean(False)
        stream.writeBoolean(False) #idk
        
        stream.writeBoolean(False) 
        stream.writeBoolean(False) 
        stream.writeBoolean(False) 
        stream.writeBoolean(False)
          
        stream.writeBoolean(False) 
        stream.writeBoolean(False) 
        stream.writeBoolean(False) 
        stream.writeBoolean(False) 
        stream.writeBoolean(False) 
        stream.writeBoolean(False) 
         
        stream.writeBoolean(False) 
        stream.writeBoolean(False) 
        stream.writeBoolean(False) 
        stream.writeBoolean(False) 
        stream.writeBoolean(False) 
        stream.writeBoolean(False) 
        stream.writeBoolean(False) 
        stream.writeBoolean(False) 
        stream.writeBoolean(False) 
        stream.writeBoolean(False) 
        stream.writeBoolean(False) 
        stream.writeBoolean(False) 
        stream.writeBoolean(False) 
        stream.writeBoolean(False) 
        stream.writeBoolean(False) 
         
        stream.writeBoolean(False) 
        stream.writeBoolean(False) 
         
        stream.writeBoolean(False) 
         
        stream.writeBoolean(False) 
         
        stream.writeBoolean(False) 
        
        stream.writeBoolean(False) #разворот карты кек кек
        
        stream.writeBoolean(False)
        stream.writeBoolean(False)
        stream.writeBoolean(False)
        stream.writeBoolean(False)
        stream.writeBoolean(False)
        stream.writeBoolean(False)
        stream.writeBoolean(False)
        stream.writeBoolean(True)
        
        stream.writeBoolean(False) #
        stream.writeBoolean(False)
        
        stream.writeBoolean(False) #d  array
        stream.writeBoolean(False)
        
        stream.writePositiveVInt(1, 4)
        
        stream.writePositiveInt(15, 4)
        stream.writeBoolean(True)
        
        stream.writeBoolean(False)
        stream.writeBoolean(False)
        stream.writeBoolean(False)
        stream.writeBoolean(False)
        stream.writeBoolean(False)
        stream.writeBoolean(False)
        stream.writeBoolean(False)
        stream.writeBoolean(False)
        stream.writeBoolean(False)
        stream.writeBoolean(False)
        stream.writeBoolean(False)
        stream.writePositiveVInt(0, 4)
        stream.writePositiveVInt(3150, 4) # x
        stream.writePositiveVInt(6000, 4) # y
        stream.writePositiveVInt(0+0, 4)  # i
        stream.writePVIntMax255OZ(0) # ZV 
        stream.writePositiveInt(10, 4)
        stream.writeBoolean(False)
        stream.writeBoolean(False)
        
        stream.writeBoolean(False) #power
        stream.writeBoolean(False) #power
        stream.writeBoolean(False) #power
        stream.writeBoolean(False) #power
        stream.writeInt(63, 6)
        stream.writeBoolean(False)  #revert walk
        stream.writeBoolean(False)
        stream.writeBoolean(False)
        stream.writeBoolean(True) #power
        
        stream.writePVIntMax65535OZ(0) 
        stream.writePVIntMax65535OZ(0) 
        stream.writeBoolean(False) 
        stream.writeBoolean(False) 
        stream.writeBoolean(False) 
        stream.writeBoolean(False)
        stream.writeBoolean(False) 
        stream.writeBoolean(False) 
        stream.writeBoolean(False) 
        stream.writeBoolean(False)
        
        stream.writeBoolean(False) #power
        stream.writeBoolean(False) #power
        stream.writeBoolean(False) #power
        stream.writeBoolean(False) #power
        stream.writeBoolean(False) #power
        stream.writeBoolean(False) #power
        
        stream.writePVIntMax255OZ(0) 
        stream.writePVIntMax255OZ(0) 
        stream.writePVIntMax255OZ(0)
        stream.writePositiveVInt(2800, 4) 
        stream.writePositiveVInt(2800, 4) 
        stream.writePVIntMax255OZ(0) 
        
        stream.writeBoolean(False)
        stream.writeBoolean(False)
        
        stream.writePVIntMax255OZ(1)
        stream.writeBoolean(False)
        stream.writeBoolean(False)
        
        stream.writeBoolean(True)
        stream.writeBoolean(False)
        stream.writeBoolean(False)
        stream.writeBoolean(False)
        stream.writeBoolean(False)
        stream.writeBoolean(False)
        
        
        stream.writeBoolean(False)
        stream.writeBoolean(False)
        stream.writeBoolean(False)
        
        stream.writeBoolean(False)
        stream.writeBoolean(False) #power
        stream.writeBoolean(False) #power
        
        stream.writeBoolean(False)
        stream.writeBoolean(False) #power
        stream.writeBoolean(False) #power
        stream.writeBoolean(False) #power
        stream.writeBoolean(False) #power
        stream.writeBoolean(False) #power
        stream.writeBoolean(False) #power
        stream.writeBoolean(False) #power
        stream.writeBoolean(False) #power
        stream.writeBoolean(False) #power
        
        stream.writeBoolean(False)
        stream.writeBoolean(False)
        
        stream.writeBoolean(False) #
        stream.writeBoolean(False)
        stream.writeBoolean(False)
        
        stream.writeBoolean(False) #power
        stream.writeBoolean(False) #power
        stream.writeBoolean(False) #power
        stream.writeBoolean(False) #power
        stream.writeBoolean(False) #power
        stream.writePVIntMax255OZ(0)
        stream.writeBoolean(False)
        stream.writePVIntMax255OZ(0)
        stream.writeBoolean(False) #power
        stream.writeBoolean(False) #power
        stream.writeBoolean(False) #power
        stream.writeBoolean(False) #power
        stream.writeBoolean(False) #power
        stream.writeBoolean(False) #power
        stream.writeBoolean(False) #power
        stream.writeBoolean(False) #power
        stream.writeBoolean(False) #power
        stream.writeBoolean(False) #power
        stream.writeBoolean(False) #power
        stream.writeBoolean(False) #power
        stream.writeBoolean(True)
        stream.writeBoolean(False)
        stream.writeBoolean(True)
        
        # GameObjects end
        
        stream.writePositiveInt(0, 8) # unknown dudka
        print("вижион апдейт сент")
        
        self.writeBytes(stream.getBuff(), len(stream.getBuff()))
        
    def decode(self):
        return {}

    def execute(message, calling_instance, fields):
        pass

    def getMessageType(self):
        return 24109

    def getMessageVersion(self):
        return self.messageVersion