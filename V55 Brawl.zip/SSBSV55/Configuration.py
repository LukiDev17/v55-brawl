# Configuration Settings
# DisableNagle: Reduces delay and improves performance between client and server BUT requires more power.

settings = {
    "DisableNagle": True,  # Optimizes network performance (disable Nagle algorithm)
    "PrintEnabled": True,  # Enables debug or verbose printing
    "UseContentUpdater": False,  # Determines if the content updater is active
    "Proxy": False,  # Enables or disables proxy usage
    "DumpPacket": False,  # Dumps network packets for debugging purposes
    "Blacklist": [24109],  # List of IDs that are blacklisted
    "DumpMajor": 55,  # Current dump version (used for file naming)

    # New Settings
    "MaxConnections": 100,  # Maximum number of simultaneous connections to the server
    "EnableLogging": True,  # Toggles logging system for server events
    "LogFilePath": "logs/server.log",  # Path to the log file
    "EnableCompression": True,  # Enables compression for data transfer
    "DefaultPort": 9339,  # Default server port
    "AllowedIPs": ["127.0.0.1", "192.168.1.0/24"],  # List of IPs or subnets allowed to connect
    "ServerName": "LukiDev Server",  # Custom name for the server
}
