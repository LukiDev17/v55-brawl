import os
import Configuration
from Classes.ServerConnection import ServerConnection
from Static.StaticData import StaticData

# Debug-Info
print("Server made by st3a1 | t.me/st3a1")

# Überprüfen, ob der Schlüssel 'DumpMajor' in den Einstellungen vorhanden ist
try:
    dump_major = Configuration.settings['DumpMajor']
except KeyError:
    raise KeyError("The key 'DumpMajor' is missing in Configuration.settings.")

# Verzeichnis erstellen, falls es nicht existiert
dump_directory = f"HexDumpV{dump_major}"
if not os.path.exists(dump_directory):
    os.makedirs(dump_directory)

# Daten vorladen
StaticData.Preload()

# Server-Verbindung starten
try:
    server = ServerConnection(("0.0.0.0", 9339))
    print("Server successfully initialized.")
except Exception as e:
    print(f"Failed to initialize the server: {e}")
