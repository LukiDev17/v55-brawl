# List of numbers to convert to hexadecimal
numbers = [13]
hex_str = ''.join(format(num, 'x') for num in numbers)
print("Hexadecimal representation of numbers:", hex_str)

# Function to decode a hexadecimal string into UTF-8
def hex_decoder(hex_str):
    try:
        decoded_str = bytes.fromhex(hex_str).decode('utf-8')
        return decoded_str
    except ValueError:
        return "Invalid hex string or cannot decode to UTF-8."

# Byte array for demonstration
byte_value = b'\x9e\xd9n\x05W\xf9\xde\xea\xccy\xb1\xe4;O]\xd9\x19!q\xb9w\xab\xcd\xf6\x0b\xb9\xb9\x16\x8c\x98k\x14'

# Convert byte to hexadecimal
hex_value = byte_value.hex()  # Use the built-in .hex() method
print("Hexadecimal value of byte_value:", hex_value)

# Example of a hexadecimal string
hex_str1 = "48656c6c6f20576f726c64"  # "Hello World"

# Decode the hexadecimal string
decoded_str = hex_decoder(hex_str1)
print("Decoded string from hex_str1:", decoded_str)

# Example of another hexadecimal string and its length
str_len = "2BFDF6E5DA6D5D68C45A756F42EAD024"
print("Length of str_len:", len(str_len))
